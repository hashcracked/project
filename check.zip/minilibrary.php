<?php
//Peremennie
$vremya = date('d.m.Y, H:i'); //дата
$dmy = date('d.m.Y'); //дата2
$vremya2 = date('H:i'); //Часы/минуты
$today = date("Y-m-d H:i:s"); #дата3
$dataphp = file_get_contents('php://input');
$dataphp = json_decode($dataphp, true);
$ent = $dataphp['message']['entities'];
$stickerID = $dataphp['message']['sticker']['file_id'];
$stickerID2 = $dataphp['message']['sticker']['thumb']['file_id'];
$stickerID3 = $dataphp['message']['sticker']['set_name'];
$username = $dataphp["message"]["from"]["username"];
$namein = $dataphp["callback_query"]["from"]["username"];
$cidin = $dataphp["callback_query"]["from"]["id"];
$callback_query = $dataphp['callback_query'];
$callback = $callback_query['data'];
$trimCallback = explode(",", $callback);
$tgIDInline = $callback_query['message']['chat']['id'];
$msgIDInline = $callback_query['message']['message_id'];
$nameorig = $dataphp["message"]['from']["chat"]["username"];
$tgID = $dataphp["message"]["chat"]["id"];
$sendertittle = $dataphp["message"]["from"]['sender_chat']["title"];
$newmembercid = $dataphp["message"]["new_chat_member"]["id"];
$leftmembercid = $dataphp["message"]["left_chat_member"]["id"];
$newmembername = $dataphp["message"]['new_chat_member']["username"];
$firstnmb = $dataphp["message"]['new_chat_member']["first_name"];
$chat_idgrp = $dataphp["message"]["from"]["id"];
$text = $dataphp['message']['text'];
$text2 = $dataphp['message']['channel_post']['text'];
$contact = $dataphp['message']['contact'];
$phone = $contact['phone_number'];
$mess_id = $dataphp["message"]["message_id"];
define('bot', 'ИЗМЕНИТЬ');
function SendQuery($method, $response)
{
    $ch = curl_init('https://api.telegram.org/bot' . bot . '/' . $method);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $response);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    $res = curl_exec($ch);
    curl_close($ch);
    return $res;
}

?>
